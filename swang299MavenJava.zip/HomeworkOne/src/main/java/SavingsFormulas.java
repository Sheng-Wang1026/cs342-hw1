class SavingsFormulas{
    public static double futureValueLumpSum(double cash, double interest, int years){
        double total = cash;
        for(int i=0; i < years; i++){
            total = total * (1 + interest);
        }

        return total;
    }

    public static double futureValueLS_VariableInterest(double cash, double[] values){
        double total = cash;
        for(int i=0; i < values.length; i++){
            total = total * (1 + values[i]);
        }

        return total;
    }

    public static double compoundSavingsConstant(double cash, double interest, int years){
        double total = cash;
        for(int i=1; i < years; i++){
            total = total * (1 + interest);
            total = total + cash;
        }

        return total;
    }

    public static double compoundSavingsVariable(double[] values, double interest){
        double total = values[0];
        for(int i=1; i < values.length; i++){
            total = total * (1 + interest);
            total = total + values[i];
        }

        return total;
    }

}